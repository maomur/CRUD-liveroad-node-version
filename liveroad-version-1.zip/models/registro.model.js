//CREAR ITEM
const create = ({ pu, del, loadnumber, ocity, dcity, commodity, brokercompany, brokername, brokerphone, phoneextension, rate, truck, paidunpaid }) => {
    return db.query('INSERT INTO liveroad.registros (pu, del, loadnumber, ocity, dcity, commodity, brokercompany, brokername, brokerphone, phoneextension, rate, truck, paidunpaid) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', [pu, del, loadnumber, ocity, dcity, commodity, brokercompany, brokername, brokerphone, phoneextension, rate, truck, paidunpaid])
}

//VER TODOS LOS REGITROS
const getAll = () => {
    return db.query('SELECT * FROM liveroad.registros')
}

//VER UN ÚNICO REGISTRO
const getById = (registroId) => {
    return db.query('SELECT * FROM liveroad.registros WHERE id = ?', [registroId])
}


// ELIMINAR POR ID
const deleteById = (clienteId) => {
    return db.query('DELETE FROM liveroad.registros WHERE id = ?', [clienteId])
}
module.exports = {
    create, deleteById, getAll, getById
}