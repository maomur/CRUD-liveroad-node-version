const express = require('express');
const router = express.Router();
const RegistroModel = require('../models/registro.model');
const dayjs = require('dayjs');

/* GET home page. */
router.get('/', function (req, res) {
  res.render('index');
});

//RECUPERAR TODOS LOS REGISTROS
router.get('/data', async (req, res) => {
  const [arrRegistros] = await RegistroModel.getAll();

  for (registro of arrRegistros) {
    registro.pu = dayjs(registro.pu).format('MM-DD-YYYY')
  }

  res.render('list', {
    registros: arrRegistros
  });
})


//FORMULARIO DE REGISTRO
router.get('/new', (req, res) => {
  res.render('form');
})


//VER REGISTRO ÚNICO
router.get('/detail/:registroId', async (req, res) => {
  const [resultado] = await RegistroModel.getById(req.params.registroId);
  for (registro of resultado) {
    registro.pu = dayjs(registro.pu).format('MM-DD-YYYY')
    registro.del = dayjs(registro.del).format('MM-DD-YYYY');
  }

  res.render('detail', {
    registro: resultado[0]
  })
})


//CREAR REGISTRO
router.post('/create', async (req, res) => {
  const [resultado] = await RegistroModel.create(req.body);
  res.redirect('/data');
})


router.get('/delete/:clienteId', async (req, res) => {
  const [resultado] = await RegistroModel.deleteById(req.params.clienteId);
  res.redirect('/data')
})

module.exports = router;
